package com.ucd.oursql.sql.table.type;

import com.ucd.oursql.sql.parsing.SqlParserConstants;

public interface SqlConstant extends SqlParserConstants {

}
