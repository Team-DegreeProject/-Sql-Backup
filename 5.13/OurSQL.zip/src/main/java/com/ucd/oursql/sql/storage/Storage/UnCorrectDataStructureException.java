package com.ucd.oursql.sql.storage.Storage;

import java.sql.SQLException;

public class UnCorrectDataStructureException extends SQLException {
}
