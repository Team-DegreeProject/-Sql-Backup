package com.ucd.oursql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OursqlApplication {

    public static void main(String[] args) {
        SpringApplication.run(OursqlApplication.class, args);
    }

}
