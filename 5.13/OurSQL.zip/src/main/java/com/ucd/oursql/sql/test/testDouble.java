package com.ucd.oursql.sql.test;

import java.sql.Timestamp;

public class testDouble {
    public static void main(String[] args) {
        Timestamp t=Timestamp.valueOf("2011-11-03 08:11:09.0");
        System.out.println(t);

    }
}
