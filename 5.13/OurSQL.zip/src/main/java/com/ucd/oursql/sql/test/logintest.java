package com.ucd.oursql.sql.test;

import com.ucd.oursql.sql.login.RegristrationFunc;
import com.ucd.oursql.sql.login.account;

public class logintest {
    public static void main(String[] args) {
//        RegristrationFunc a=new RegristrationFunc();
//        a.register(new account("user1","test"));

//        String s="\\0 asjf asdnvoa \\sdva \' \"\"asdv";
//        System.out.println(s);
//        StringBuilder buf = new StringBuilder();
//        for (int j = 0; j < s.length(); j++) {
//            char c = s.charAt(j);
//            switch (c)
//            {
//                case '\0':
//                    buf.append("\\0");
//                    break;
//                case '\n':
//                    buf.append("\\n");
//                    break;
//                case '\r':
//                    buf.append("\\r");
//                    break;
//                case '\'':
//                    buf.append("\\'");
//                    break;
//                case '"':
//                    buf.append("\\\"");
//                    break;
//                case '\\':
//                    buf.append("\\\\");
//                    break;
//                case '%':
//                    buf.append("\\%");
//                    break;
//                case '_':
//                    buf.append("\\_");
//                    break;
//                default:
//                    buf.append(c);
//                    break;
//            }
//        }
//        System.out.println(buf.toString());
    }
}
