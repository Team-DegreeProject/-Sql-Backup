package com.ucd.oursql.sql.storage.Lock_regulator;

public class Configuration {
    public static final String SHARELOCK = "SHARELOCK";
    public static final String UPDATELOCK = "UPDATELOCK";
    public static final String EXCLUSIVELOCK = "EXCLUSIVELOCK";
    public static final String DElETE = "DELETE";
    public static final String UPDATE = "UPDATE";

}
