package com.ucd.oursql.sql.storage.Lock_regulator;

import java.util.ArrayList;

public class newTest {
    public static void main(String[] args) {
        int a = 0;
        int b = a;
        System.out.println(b);
        a = a+1;
        System.out.println(b);

    }
}
